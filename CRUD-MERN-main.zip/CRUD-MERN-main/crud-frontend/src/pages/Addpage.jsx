import React from "react";
import Navbar from "../components/Navbar";
import EmpForm from "../components/EmpForm";

function Addpage() {
  return (
    <>
      <Navbar />
      <EmpForm />
    </>
  );
}

export default Addpage;
