import React from "react";
import Navbar from "../components/Navbar";
import Edit from "../components/Edit";

function Editpage() {
  return (
    <>
      <Navbar />
      <Edit />
    </>
  );
}

export default Editpage;
