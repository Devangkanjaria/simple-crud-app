import React from "react";
import Navbar from "../components/Navbar";
import View from "../components/View";

function Viewpage() {
  return (
    <>
      <Navbar />
      <View />
    </>
  );
}

export default Viewpage;
