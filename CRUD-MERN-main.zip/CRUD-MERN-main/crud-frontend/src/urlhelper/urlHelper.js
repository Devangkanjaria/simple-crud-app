const backendUrl = "https://mern-crud-n9oo.onrender.com"
//   "http://localhost:5000"
module.exports = backendUrl;
